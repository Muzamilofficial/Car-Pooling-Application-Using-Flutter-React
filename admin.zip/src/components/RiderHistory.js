import React, { useEffect, useState } from "react";
import { getDriverSchedule, getRiderHistory } from "../api";

const RiderHistory = () => {
  const [riderHistory, setRiderHistory] = useState([]);
  const [driverSchedule, setDriverSchedule] = useState([
    {
      availableSeats: "2",
      carType: "Car AC",
      date: "2024-05-15T00:00:00.000",
      driverId: "HvJfLAp6lJO44VMEglZkUxvdPst1",
      fares: "250"
    }
  ]);

  useEffect(() => {
    getRiderHistory().then((historyData) => {
      setRiderHistory(historyData);
    });
    getDriverSchedule().then((scheduleData) => {
      setDriverSchedule(scheduleData);
    });
  }, []);

  return (
    <div className="content-section">
      <h3>Drivers Schedule</h3>
      <div class="table-wrapper">
        <table class="fl-table">
          <thead>
            <tr>
              <th>Driver Name</th>
              <th>Car Type</th>
              <th>Available Seats</th>
              <th>Fares</th>
              <th>Time</th>
              <th>No of Requests</th>
            </tr>
          </thead>
          <tbody>
            {
              driverSchedule.map((driver, index) => (
                <tr key={driver.driverId+index}>
                  <td>{driver.driverName}</td>
                  <td>{driver.carType}</td>
                  <td>{driver.availableSeats}</td>
                  <td>{driver.fares}</td>
                  <td>{driver.time}</td>
                  <td>{driver?.requests?.length}</td>
                </tr>
              ))
            }
          </tbody>
        </table>
      </div>
      <h3>Ride History</h3>
      <div className="ride-listings">
        {riderHistory.map((ride) => (
          <div className="ride-item" key={ride.user_id}>
            <p><span class="bold-text">Rider ID:</span> {ride.driver_id}</p>
            <p><span class="bold-text">Rider Name:</span> {ride.driver_name}</p>

            <p><span class="bold-text">Status:</span> {ride.status}</p>
            <p><span class="bold-text">User ID:</span> {ride.user_id}</p>

            <p><span class="bold-text">Passenger Name:</span> {ride.passenger_name}</p>
            <p><span class="bold-text">Passenger Email:</span> {ride.passenger_email}</p>
            <p><span class="bold-text">Passenger Phone:</span> {ride.passenger_phone}</p>
            <p><span class="bold-text">Pickup Location:</span> {ride.pickupLocation}</p>
            <p><span class="bold-text">Drop-off Location:</span> {ride.dropOffLocation}</p>
            <p><span class="bold-text">From Latitude:</span>{ride.fromLatitude}</p>
            <p><span class="bold-text">To Latitude:</span>{ride.toLatitude}</p>
            <p><span class="bold-text">From Longitude:</span> {ride.fromLongitute}</p>
            <p><span class="bold-text">To Longitude:</span> {ride.toLongitute}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RiderHistory;
