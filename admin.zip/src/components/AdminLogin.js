import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import logo from '../assets/logo.png';
//import firebase from 'firebase/compat/app';

const AdminLogin = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  
  const handleLogin = async () => {
    // Validate username and password
    if (username === 'admin' && password === 'password') {
      navigate('/admin');
      // Test the connection with the Realtime Database
      //await testDatabaseConnection();
    } else {
      alert('Invalid username or password');
    }
  };

  // const testDatabaseConnection = async () => {
  //   const database = firebase.database();
  //   const testRef = database.ref('/'); // Replace 'test' with an existing path in your database

  //   try {
  //     const snapshot = await testRef.once('value');
  //     const data = snapshot.val();
  //     console.log('Data from Realtime Database:', data);
  //   } catch (error) {
  //     console.error('Error reading data from Realtime Database:', error);
  //   }
  // };
  

  return (
    <div className="login">
      <div className="login-box">
      <div className="logo">
        <div className="logo-container">
          <img src={logo} alt="Logo" />
          
      </div>  
      <div className="divider-line"></div>
      </div>
        <h2>Sign in as administrator</h2>
        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button onClick={handleLogin}>Sign in</button>
      </div>
    </div>
  );
};

export default AdminLogin;
