import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUsers, faClipboardList, faUser, faCar } from '@fortawesome/free-solid-svg-icons';
import logo from '../assets/logo.png';
import {faCircleChevronLeft, faAngleLeft } from '@fortawesome/free-solid-svg-icons';
export const Sidebar = () => {
  const navigate = useNavigate();
  
  const [activeMenu, setActiveMenu] = useState('users'); // Set the default active button here
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false); // Add state for sidebar visibility

  

  const handleClickDrivers = () => {
    navigate('/admin/drivers');
    setActiveMenu('drivers');
  };

  const handleClickUsers = () => {
    navigate('/admin');
    setActiveMenu('users');
  };

  const handleClickRiderHistory = () => {
    navigate('/admin/rider-history');
    setActiveMenu('rider-history');
  };

  const handleClickActiveDrivers = () => {
    navigate('/admin/active-drivers');
    setActiveMenu('active-drivers');
  };

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };


  return (
  <div className={`sidebar ${isSidebarCollapsed ? 'collapsed' : ''}`}>
    <div className="sidebar">
      
      <div className="logo">
        <div className="logo-container">
          <img src={logo} alt="Logo" />
          <div className="brand-name">DriveCarte</div>
        </div>  
      <div className="divider-line"></div>
      </div>
      

      <div className="divider"></div>
      <nav>
        <ul className="nav-menu">
          <li onClick={handleClickDrivers} className={activeMenu === 'drivers' ? 'active-btn' : ''}>
            <FontAwesomeIcon icon={faUsers} />
            <span>Manage Riders</span>
          </li>
          <li onClick={handleClickUsers} className={activeMenu === 'users' ? 'active-btn' : ''}>
            <FontAwesomeIcon icon={faUser} />
            <span>Manage Users</span>
          </li>
          <li onClick={handleClickRiderHistory} className={activeMenu === 'rider-history' ? 'active-btn' : ''}>
            <FontAwesomeIcon icon={faClipboardList} />
            <span>Ride History</span>
          </li>
          <li onClick={handleClickActiveDrivers} className={activeMenu === 'active-drivers' ? 'active-btn' : ''}>
            <FontAwesomeIcon icon={faCar} />
            <span>Online Riders</span>
          </li>
        </ul>
      </nav>
      <div className="divider-line"></div>
      <button onClick={toggleSidebar}>
      {/* <FontAwesomeIcon icon={faCircleChevronLeft} /> */}
      <FontAwesomeIcon icon={faAngleLeft} id='toggleicon' />
      </button>
      </div>

      
    </div>
    
  );
};

export default Sidebar                    ;
