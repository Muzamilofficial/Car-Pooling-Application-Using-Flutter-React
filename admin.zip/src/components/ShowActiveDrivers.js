import React, { useEffect, useState } from "react";
import { Map, Marker, GoogleApiWrapper } from "google-maps-react";
import { getActiveDrivers, getDrivers } from "../api";
import carImg from '../assets/car-img.png'
import bikeImg from '../assets/bike-img.png'

const ShowActiveDrivers = ({ google }) => {
  const [activeDrivers, setActiveDrivers] = useState([]);

  // useEffect(() => {
  //   getActiveDrivers()
  //     .then((driversData) => {
  //       setActiveDrivers(driversData);
  //     })
  //     .catch((error) => {
  //       console.error("Error fetching active drivers:", error);
  //     });
  // }, []);
  useEffect(() => {
    getDrivers()
      .then((driversData) => {
        driversData.forEach((driver) => {
          if(driver.location){
            driver.latitude = driver.location.split(", ")[0];
            driver.longitude = driver.location.split(", ")[1];
          }
        });
        let onlineDrivers = driversData.filter((driver) => driver.status === "Online");
        console.log("driversData", onlineDrivers);
        setActiveDrivers(onlineDrivers);
      })
      .catch((error) => {
        console.error("Error fetching active drivers:", error);
      });
  }, []);

  if (!google || activeDrivers.length === 0) {
    console.log('activeDrivers', activeDrivers);
    return <div>Loading...</div>;
  }

  // Calculate the average coordinates of active drivers
  const avgLat = activeDrivers.reduce((sum, driver) => sum + driver.latitude, 0) / activeDrivers.length;
  const avgLng = activeDrivers.reduce((sum, driver) => sum + driver.longitude, 0) / activeDrivers.length;
  const averageCenter = { lat: avgLat, lng: avgLng };

  return (
    <div className="content-section">
      <h3>Active Drivers</h3>
      <div className="active-listings">
        <div
          style={{
            position: "relative",
            width: "100%",
            paddingBottom: "50%", // Maintain aspect ratio of 2:1 (height:width)
          }}
        >
          <Map
            google={google}
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              width: "100%",
              height: "100%",
            }}
            initialCenter={averageCenter} // Use the average coordinates as the initial center
            zoom={15} // Adjust the zoom level as needed (smaller value = less zoomed in)
          >
            {activeDrivers.map((driver) => (
              <Marker
                key={driver.id}
                position={{ lat: driver.latitude, lng: driver.longitude }}
                icon={{
                  url: carImg,
                  anchor: new google.maps.Point(32,32),
                  scaledSize: new google.maps.Size(64,64)
                }}
                name={driver.name}
              />
            ))}
          </Map>
        </div>
      </div>
    </div>
  );
};

export default GoogleApiWrapper({
  apiKey: "AIzaSyDl1pFZteFPZBB2vH2f8BHm6zplU0fp7xI"
})(ShowActiveDrivers);