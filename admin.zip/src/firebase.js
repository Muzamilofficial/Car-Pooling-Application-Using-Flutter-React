// firebase.js
import firebase from 'firebase/compat/app';
import 'firebase/compat/database';

const firebaseConfig = {
  apiKey: "AIzaSyAftdWeGNrkjWPNM9AWHm-we1HvlJKAXgg",
  authDomain: "carpolfyp.firebaseapp.com",
  databaseURL: "https://carpolfyp-default-rtdb.firebaseio.com",
  projectId: "carpolfyp",
  storageBucket: "carpolfyp.appspot.com",
  messagingSenderId: "230154274088",
  appId: "1:230154274088:web:bf9decf34064ad99ff7c1d",
  measurementId: "G-11DBH1ECXM"
};

firebase.initializeApp(firebaseConfig);

export const database = firebase.database();


export default database;
